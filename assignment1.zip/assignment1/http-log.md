Request No 1: curl  -i https://jsonplaceholder.typicode.com/users/1
HTTP/2 200 : refers to the succesful retrevial of the request from the server
date: Sun, 16 Aug 2026 05:17:56 GMT
content-type: application/json; charset=utf-8
content-length: 509
access-control-allow-credentials: true

{
  "id": 1,
  "name": "Leanne Graham",
  "username": "Bret",
  "email": "Sincere@april.biz",
  "address": {
    "street": "Kulas Light",
    "suite": "Apt. 556",
    "city": "Gwenborough",
    "zipcode": "92998-3874",
    "geo": {
      "lat": "-37.3159",
      "lng": "81.1496"
    }
  },
  "phone": "1-770-736-8031 x56442",
  "website": "hildegard.org",
  "company": {
    "name": "Romaguera-Crona",
    "catchPhrase": "Multi-layered client-server neural-net",
    "bs": "harness real-time e-markets"
  }
}

Request No 2: curl  -i https://jsonplaceholder.typicode.com/users/2
HTTP/2 200 
date: Sun, 16 Aug 2026 06:35:19 GMT
content-type: application/json; charset=utf-8
content-length: 509
{
  "id": 2,
  "name": "Ervin Howell",
  "username": "Antonette",
  "email": "Shanna@melissa.tv",
  "address": {
    "street": "Victor Plains",
    "suite": "Suite 879",
    "city": "Wisokyburgh",
    "zipcode": "90566-7771",
    "geo": {
      "lat": "-43.9509",
      "lng": "-34.4618"
    }
  },
  "phone": "010-692-6593 x09125",
  "website": "anastasia.net",
  "company": {
    "name": "Deckow-Crist",
    "catchPhrase": "Proactive didactic contingency",
    "bs": "synergize scalable supply-chains"
  }

}

Request No 3 : curl  -i https://jsonplaceholder.typicode.com/users/3
HTTP/2 200 
date: Sun, 16 Aug 2026 06:37:41 GMT
content-type: application/json; charset=utf-8
content-length: 520

{
  "id": 3,
  "name": "Clementine Bauch",
  "username": "Samantha",
  "email": "Nathan@yesenia.net",
  "address": {
    "street": "Douglas Extension",
    "suite": "Suite 847",
    "city": "McKenziehaven",
    "zipcode": "59590-4157",
    "geo": {
      "lat": "-68.6102",
      "lng": "-47.0653"
    }
  },
  "phone": "1-463-123-4447",
  "website": "ramiro.info",
  "company": {
    "name": "Romaguera-Jacobson",
    "catchPhrase": "Face to face bifurcated interface",
    "bs": "e-enable strategic applications"
  }
}

Request No 4: curl  -i https://jsonplaceholder.typicode.com/users/4
HTTP/2 200 
date: Sun, 16 Aug 2026 06:38:52 GMT
content-type: application/json; charset=utf-8
content-length: 525

{
  "id": 4,
  "name": "Patricia Lebsack",
  "username": "Karianne",
  "email": "Julianne.OConner@kory.org",
  "address": {
    "street": "Hoeger Mall",
    "suite": "Apt. 692",
    "city": "South Elvis",
    "zipcode": "53919-4257",
    "geo": {
      "lat": "29.4572",
      "lng": "-164.2990"
    }
  },
  "phone": "493-170-9623 x156",
  "website": "kale.biz",
  "company": {
    "name": "Robel-Corkery",
    "catchPhrase": "Multi-tiered zero tolerance productivity",
    "bs": "transition cutting-edge web services"
  }
}

Request No 5: curl  -i https://jsonplaceholder.typicode.com/users/11
HTTP/2 404 : The server couldn't find the required resourece. 
date: Sun, 16 Aug 2026 06:39:21 GMT
content-type: application/json; charset=utf-8
content-length: 2
