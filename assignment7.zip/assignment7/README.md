# CampusEats Catalogue GraphQL Assignment

This small demo exposes the CampusEats catalogue through Apollo Server and PostgreSQL. It is a standalone assignment project and does not change the existing CampusEats API.

## Answers

1. **Which CampusEats service did you pick?**  
   The Catalogue service, represented here by menu items with a name, category, price, and optional description.

2. **Name one field a client can skip and one it cannot. Why use `!`?**  
   A client can skip `description` because the GraphQL field is nullable (`String`). A client cannot omit `name` from the `addCatalogueItem` mutation because its argument is `String!`. The `!` marks a non-null field or argument, so GraphQL rejects a request that omits it or supplies `null`.

3. **Map the request to PostgreSQL: which part became `WHERE`, and which resolver ran `INSERT`?**  
   The `catalogueItem(id: ID!)` query passes its `id` argument to the `$1` parameter in `WHERE id = $1`. The `Mutation.addCatalogueItem` resolver runs an `INSERT INTO catalogue_demo_items ... RETURNING ...` statement.

## Run it locally

Requirements: Node.js 20 or newer and PostgreSQL.

1. The demo uses the existing CampusEats `DATABASE_URL` from the repository-root `.env` when available. If you do not have a database configured, create a PostgreSQL login and database:

   ```sh
   createuser campuseats_graphql --pwprompt
   createdb -O campuseats_graphql campuseats_graphql
   ```

   Set a password when prompted. If your local PostgreSQL setup already has a suitable database and role, you can use those instead.

2. Install Node dependencies and configure a database connection:

   ```sh
   npm install
   cp .env.example .env
   ```

   Edit `.env` to use the password chosen for the database role. The assignment-local `.env` takes precedence over the repository-root `.env`.

3. Load the table and four seed items. Run this from `assignment_graphql/`; PostgreSQL will prompt for the role password:

   ```sh
   psql -h localhost -U campuseats_graphql -d campuseats_graphql -W -f schema.sql
   ```

   If using the existing CampusEats database, substitute its host, username, and database name.

4. Start the server:

   ```sh
   npm start
   ```

5. Open <http://localhost:4000/>. The page lists the seed records. Add an item in the form; the GraphQL mutation inserts it into PostgreSQL and the page refreshes the list. Apollo's endpoint is <http://localhost:4000/graphql>.

## Example GraphQL operations

List all records:

```graphql
query {
  catalogueItems {
    id
    name
    category
    price
    description
  }
}
```

Find one record by ID:

```graphql
query {
  catalogueItem(id: "1") {
    id
    name
    price
  }
}
```

Add a record:

```graphql
mutation {
  addCatalogueItem(
    name: "Idli Sambar"
    category: "Breakfast"
    price: 50
    description: "Steamed idlis with sambar"
  ) {
    id
    name
    category
    price
  }
}
```

## Live demonstration screenshots

Before adding an item: `screenshots/before.png`  
After adding **Idli Sambar**: `screenshots/after.png`

### Before

![Catalogue before adding Idli Sambar](screenshots/before.png)

### After

![Catalogue after adding Idli Sambar](screenshots/after.png)
