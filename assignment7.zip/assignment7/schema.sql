CREATE TABLE IF NOT EXISTS catalogue_demo_items (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price NUMERIC(8, 2) NOT NULL CHECK (price >= 0),
    description TEXT
);

INSERT INTO catalogue_demo_items (name, category, price, description)
SELECT seed.name, seed.category, seed.price, seed.description
FROM (
    VALUES
        ('Masala Dosa', 'Breakfast', 80.00::NUMERIC(8, 2), 'Crisp dosa with potato masala'),
        ('Veg Thali', 'Lunch', 140.00::NUMERIC(8, 2), 'A filling campus lunch plate'),
        ('Paneer Wrap', 'Snacks', 95.00::NUMERIC(8, 2), 'Paneer and vegetables in a soft wrap'),
        ('Cold Coffee', 'Drinks', 60.00::NUMERIC(8, 2), 'Chilled coffee')
) AS seed(name, category, price, description)
WHERE NOT EXISTS (
    SELECT 1
    FROM catalogue_demo_items existing
    WHERE existing.name = seed.name
);
