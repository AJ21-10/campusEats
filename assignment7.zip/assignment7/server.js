const { ApolloServer } = require('@apollo/server');
const { expressMiddleware } = require('@as-integrations/express4');
const express = require('express');
const { readFile } = require('node:fs/promises');
const path = require('node:path');

const db = require('./db');

async function startServer() {
  const typeDefs = await readFile(path.join(__dirname, 'schema.graphql'), 'utf8');

  const resolvers = {
    Query: {
      catalogueItems: async () => {
        const { rows } = await db.query(
          `SELECT id, name, category, price, description
           FROM catalogue_demo_items
           ORDER BY id`,
        );
        return rows;
      },
      catalogueItem: async (_parent, { id }) => {
        const { rows } = await db.query(
          `SELECT id, name, category, price, description
           FROM catalogue_demo_items
           WHERE id = $1`,
          [id],
        );
        return rows[0] || null;
      },
    },
    Mutation: {
      addCatalogueItem: async (_parent, { name, category, price, description }) => {
        const { rows } = await db.query(
          `INSERT INTO catalogue_demo_items (name, category, price, description)
           VALUES ($1, $2, $3, $4)
           RETURNING id, name, category, price, description`,
          [name, category, price, description ?? null],
        );
        return rows[0];
      },
    },
  };

  const apollo = new ApolloServer({ typeDefs, resolvers });
  await apollo.start();

  const app = express();
  app.use(express.static(path.join(__dirname, 'public')));
  app.use(
    '/graphql',
    express.json(),
    expressMiddleware(apollo),
  );

  const port = Number(process.env.PORT || 4000);
  const httpServer = app.listen(port, () => {
    console.log(`CampusEats GraphQL demo: http://localhost:${port}`);
    console.log(`GraphQL endpoint: http://localhost:${port}/graphql`);
  });

  const shutdown = async () => {
    httpServer.close();
    await apollo.stop();
    await db.end();
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
}

startServer().catch(async (error) => {
  console.error('Unable to start the CampusEats GraphQL demo:', error);
  await db.end();
  process.exitCode = 1;
});
